// ============================================
// GEMINI API CLIENT — Member 2's Core Service
// ============================================
// Owner: MEMBER 2 (AI/Logic Engineer)
// Purpose: Reusable wrapper around Google Gemini API

const { GoogleGenerativeAI } = require("@google/generative-ai");
const config = require("../config");

// Initialize Gemini
const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: {
        temperature: 0.7,
        topP: 0.9,
        maxOutputTokens: 8192,
        responseMimeType: "application/json", // Force JSON output
    },
});

/**
 * Send a prompt to Gemini and get a response
 * @param {string} systemPrompt - The system instruction for the AI
 * @param {string} userText - The content to transform
 * @returns {string} - Raw AI response text
 */
async function generateWithPrompt(systemPrompt, userText) {
    try {
        const result = await model.generateContent([
            {
                role: "user",
                parts: [
                    {
                        text: `${systemPrompt}\n\n---\n\nHere is the educational content to transform:\n\n${userText}`,
                    },
                ],
            },
        ]);

        const responseText = result.response.text();
        return responseText;
    } catch (error) {
        console.error("Gemini API Error:", error.message);
        throw new Error(`Gemini API failed: ${error.message}`);
    }
}

/**
 * Parse Gemini response as JSON with fallback error handling
 * @param {string} rawResponse - Raw text from Gemini
 * @param {string} modeName - Name of the mode for error context
 * @returns {object} - Parsed JSON object
 */
function parseGeminiJSON(rawResponse, modeName) {
    try {
        // Try direct parse first
        return JSON.parse(rawResponse);
    } catch (e) {
        // Try extracting JSON from markdown code block
        const jsonMatch = rawResponse.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
        if (jsonMatch) {
            try {
                return JSON.parse(jsonMatch[1]);
            } catch (e2) {
                // ignore
            }
        }

        console.error(`Failed to parse ${modeName} response as JSON:`, rawResponse.substring(0, 200));
        throw new Error(`${modeName}: AI returned invalid JSON. Please retry.`);
    }
}

module.exports = { generateWithPrompt, parseGeminiJSON };
