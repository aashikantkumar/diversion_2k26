// ============================================
// EXPRESS SERVER — Shared Entry Point
// ============================================
// Owner: Shared (Member 2 adds /api/transform, Member 3 adds /api/upload & /api/lessons)

const express = require("express");
const cors = require("cors");
const path = require("path");
const config = require("./config");

const app = express();

// --------------- Middleware ---------------
app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve static files (sign language videos, etc.)
app.use("/assets", express.static(path.join(__dirname, "../public/assets")));

// --------------- Routes ---------------

// Member 2: AI Transformation Engine
const transformRoute = require("./routes/transform");
app.use("/api/transform", transformRoute);

// Member 3: PDF Upload & Lesson Management
const uploadRoute = require("./routes/upload");
app.use("/api/upload", uploadRoute);

const lessonsRoute = require("./routes/lessons");
app.use("/api/lessons", lessonsRoute);

// --------------- Health Check ---------------
app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        timestamp: new Date().toISOString(),
        members: {
            member2_ai: !!config.GEMINI_API_KEY ? "configured" : "MISSING API KEY",
            member3_db: !!config.SUPABASE_URL ? "configured" : "MISSING SUPABASE URL",
        },
    });
});

// --------------- Error Handler ---------------
app.use((err, req, res, next) => {
    console.error("Server Error:", err.message);
    res.status(500).json({
        error: "Internal server error",
        details: config.NODE_ENV === "development" ? err.message : undefined,
    });
});

// --------------- Start Server ---------------
app.listen(config.PORT, () => {
    console.log(`
  ╔══════════════════════════════════════════════╗
  ║  🧠 NeuroAdapt Backend Running              ║
  ║  📍 http://localhost:${config.PORT}                  ║
  ║  🔑 Gemini API: ${config.GEMINI_API_KEY ? "✅ Configured" : "❌ Missing"}            ║
  ║  🗄️  Supabase:  ${config.SUPABASE_URL ? "✅ Configured" : "❌ Missing"}            ║
  ╚══════════════════════════════════════════════╝
  `);
});

module.exports = app;
