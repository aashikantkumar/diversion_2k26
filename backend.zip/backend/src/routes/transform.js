// ============================================
// TRANSFORM ROUTE — Member 2's Main Route
// ============================================
// Owner: MEMBER 2 (AI/Logic Engineer)
// Endpoint: POST /api/transform
// Purpose: Receives raw text, runs 5 parallel Gemini calls, returns structured JSON

const express = require("express");
const router = express.Router();
const { generateWithPrompt, parseGeminiJSON } = require("../services/geminiClient");
const { chunkText } = require("../services/chunker");
const { dyslexiaPrompt } = require("../services/prompts/dyslexia");
const { adhdPrompt } = require("../services/prompts/adhd");
const { dyscalculiaPrompt } = require("../services/prompts/dyscalculia");
const { simplifiedPrompt } = require("../services/prompts/simplified");
const { audioScriptPrompt } = require("../services/prompts/audioScript");

router.post("/", async (req, res) => {
    const startTime = Date.now();

    try {
        const { title, rawText, subject } = req.body;

        // Validate input
        if (!rawText || rawText.trim().length === 0) {
            return res.status(400).json({
                error: "Missing required field: rawText",
                hint: "Send a POST request with { title, rawText, subject? }",
            });
        }

        console.log(`\n🧠 Transform request: "${title || "Untitled"}"`);
        console.log(`   📝 Text length: ${rawText.length} chars`);

        // 1. Chunk the text for better processing
        const sections = chunkText(rawText, 3000);
        const fullText = sections.join("\n\n");
        console.log(`   📦 Split into ${sections.length} chunk(s)`);

        // 2. Fire ALL 5 prompts in PARALLEL
        console.log("   🚀 Firing 5 parallel Gemini API calls...");

        const [
            dyslexiaRaw,
            adhdRaw,
            dyscalculiaRaw,
            simplifiedRaw,
            audioScriptRaw,
        ] = await Promise.all([
            generateWithPrompt(dyslexiaPrompt(subject), fullText),
            generateWithPrompt(adhdPrompt(subject), fullText),
            generateWithPrompt(dyscalculiaPrompt(subject), fullText),
            generateWithPrompt(simplifiedPrompt(subject), fullText),
            generateWithPrompt(audioScriptPrompt(subject), fullText),
        ]);

        console.log("   ✅ All 5 API calls completed!");

        // 3. Parse all responses as JSON
        const dyslexia = parseGeminiJSON(dyslexiaRaw, "dyslexia");
        const adhd = parseGeminiJSON(adhdRaw, "adhd");
        const dyscalculia = parseGeminiJSON(dyscalculiaRaw, "dyscalculia");
        const simplified = parseGeminiJSON(simplifiedRaw, "simplified");
        const audioScript = parseGeminiJSON(audioScriptRaw, "audioScript");

        const processingTime = Date.now() - startTime;

        // 4. Build the final response matching the API contract
        const response = {
            id: `lesson_${Date.now()}`,
            title: title || "Untitled Lesson",
            original: rawText,
            dyslexia,
            adhd,
            dyscalculia,
            simplified,
            audioScript,
            signLanguage: {
                available: (title || "").toLowerCase().includes("solar"),
                videoUrl: "/assets/sign-language/solar-system.mp4",
                summary: "Pre-recorded sign language summary",
            },
            metadata: {
                processingTimeMs: processingTime,
                modelUsed: "gemini-1.5-flash",
                chunksProcessed: sections.length,
                textLength: rawText.length,
            },
        };

        console.log(`   ⏱️  Total processing time: ${processingTime}ms`);
        res.json(response);
    } catch (err) {
        const processingTime = Date.now() - startTime;
        console.error(`   ❌ Transform failed after ${processingTime}ms:`, err.message);
        res.status(500).json({
            error: "Transformation failed",
            details: err.message,
            processingTimeMs: processingTime,
        });
    }
});

module.exports = router;
