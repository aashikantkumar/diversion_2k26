// ============================================
// UPLOAD ROUTE — Member 3's Main Route
// ============================================
// Owner: MEMBER 3 (Data Plumber)
// Endpoint: POST /api/upload
// Purpose: Accept PDF upload → extract text → call Member 2's transform → save to DB → return

const express = require("express");
const router = express.Router();
const upload = require("../middleware/multerConfig");
const { extractTextFromPDF } = require("../services/pdfExtractor");
const { saveLesson } = require("../services/supabaseClient");

// Import Member 2's transform logic directly (internal call, not HTTP)
const { generateWithPrompt, parseGeminiJSON } = require("../services/geminiClient");
const { chunkText } = require("../services/chunker");
const { dyslexiaPrompt } = require("../services/prompts/dyslexia");
const { adhdPrompt } = require("../services/prompts/adhd");
const { dyscalculiaPrompt } = require("../services/prompts/dyscalculia");
const { simplifiedPrompt } = require("../services/prompts/simplified");
const { audioScriptPrompt } = require("../services/prompts/audioScript");

router.post("/", upload.single("pdf"), async (req, res) => {
    const startTime = Date.now();

    try {
        // 1. Validate file was uploaded
        if (!req.file) {
            return res.status(400).json({
                error: "No PDF file uploaded",
                hint: "Send a multipart/form-data request with a 'pdf' field containing the PDF file",
            });
        }

        console.log(`\n📄 Upload received: ${req.file.originalname} (${(req.file.size / 1024).toFixed(1)} KB)`);

        // 2. Extract text from PDF
        const pdfData = await extractTextFromPDF(req.file.buffer);
        console.log(`   📝 Extracted ${pdfData.text.length} chars from ${pdfData.numPages} page(s)`);

        if (!pdfData.text || pdfData.text.trim().length < 10) {
            return res.status(400).json({
                error: "PDF appears to be empty or contains only images",
                hint: "Upload a PDF with selectable text content",
            });
        }

        // 3. Use the title from request body, or fallback to PDF metadata, or filename
        const title = req.body.title
            || pdfData.info.title
            || req.file.originalname.replace(".pdf", "");
        const subject = req.body.subject || pdfData.info.subject || "general";

        // 4. Call Member 2's AI transformation (direct function call, not HTTP)
        console.log("   🧠 Starting AI transformation...");

        const sections = chunkText(pdfData.text, 3000);
        const fullText = sections.join("\n\n");

        const [
            dyslexiaRaw,
            adhdRaw,
            dyscalculiaRaw,
            simplifiedRaw,
            audioScriptRaw,
        ] = await Promise.all([
            generateWithPrompt(dyslexiaPrompt(subject), fullText),
            generateWithPrompt(adhdPrompt(subject), fullText),
            generateWithPrompt(dyscalculiaPrompt(subject), fullText),
            generateWithPrompt(simplifiedPrompt(subject), fullText),
            generateWithPrompt(audioScriptPrompt(subject), fullText),
        ]);

        const dyslexia = parseGeminiJSON(dyslexiaRaw, "dyslexia");
        const adhd = parseGeminiJSON(adhdRaw, "adhd");
        const dyscalculia = parseGeminiJSON(dyscalculiaRaw, "dyscalculia");
        const simplified = parseGeminiJSON(simplifiedRaw, "simplified");
        const audioScript = parseGeminiJSON(audioScriptRaw, "audioScript");

        const processingTime = Date.now() - startTime;
        const lessonId = `lesson_${Date.now()}`;

        // 5. Build the response
        const response = {
            id: lessonId,
            title,
            original: pdfData.text,
            dyslexia,
            adhd,
            dyscalculia,
            simplified,
            audioScript,
            signLanguage: {
                available: title.toLowerCase().includes("solar"),
                videoUrl: "/assets/sign-language/solar-system.mp4",
                summary: "Pre-recorded sign language summary",
            },
            metadata: {
                processingTimeMs: processingTime,
                modelUsed: "gemini-1.5-flash",
                pdfPages: pdfData.numPages,
                originalFileName: req.file.originalname,
                textLength: pdfData.text.length,
            },
        };

        // 6. Save to Supabase (non-blocking — don't wait for DB)
        saveLesson({
            id: lessonId,
            title,
            rawText: pdfData.text,
            subject,
            transformedJSON: response,
        }).catch((err) => console.error("   ⚠️ Background save failed:", err.message));

        console.log(`   ✅ Upload + Transform complete in ${processingTime}ms`);
        res.json(response);
    } catch (err) {
        const processingTime = Date.now() - startTime;
        console.error(`   ❌ Upload failed after ${processingTime}ms:`, err.message);
        res.status(500).json({
            error: "Upload and transformation failed",
            details: err.message,
            processingTimeMs: processingTime,
        });
    }
});

module.exports = router;
